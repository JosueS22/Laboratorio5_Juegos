﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pelota : MonoBehaviour
{
    public float fuerza = 5f;
    public Rigidbody rb;
    private static int contador = 0;

    public AudioSource coinSound;
    public AudioSource dieSound;
    public AudioSource jumpSound;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        AudioSource[] audios = GetComponents<AudioSource>();
        jumpSound = audios[0];
        coinSound = audios[1];
        dieSound = audios[2];
    }
    
    void Update()
    {
        if (rb)
        {
            if (Input.GetButtonDown("Jump"))
            {
                if (Mathf.Abs(rb.velocity.y) < 0.005f)
                {
                    jumpSound.Play();
                    rb.AddForce(0, fuerza, 0, ForceMode.Impulse);
                }
            }
        }
    }

    private void FixedUpdate()
    {
        if (rb)
        {
            rb.AddForce(Input.GetAxis("Horizontal") * -2*fuerza, 0, Input.GetAxis("Vertical") * -2*fuerza);
        }
    }


    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Peligro")
        {
            dieSound.Play();
            if (contador != 5)
            {
                Destroy(gameObject);
            }
        }

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Moneda")
        {
            coinSound.Play();
            Destroy(other.gameObject);
            contador += 1;

        }

    }
    
    


}
