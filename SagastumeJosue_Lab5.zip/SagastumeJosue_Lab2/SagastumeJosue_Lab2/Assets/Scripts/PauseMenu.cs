﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public static bool isPause = false;
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
            if (isPause)
            {
                Continue();
            }
            else
            {
                Pause();
            }
    }

    public void Pause()
    {
        transform.Find("PauseMenu").gameObject.SetActive(true);
        Time.timeScale = 0.0f;
        isPause = true;
    }

    public void Continue()
    {
        transform.Find("PauseMenu").gameObject.SetActive(false);
        Time.timeScale = 1.0f;
        isPause = false;
    }

    public void LoadMenu()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("Menu Principal");
    }

    public void QuitGame()
    {
        Debug.Log("Quitando juego...");
        Application.Quit();
    }

    
}
