﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{
    public GameObject Pelota;
    public GameObject currPlayer;
    

    void Start()
    {
        currPlayer = Instantiate(Pelota, new Vector3(35, 7, -35), Quaternion.identity);
    }
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (Pelota)
            {
                if (!currPlayer)
                {
                    currPlayer = Instantiate(Pelota, new Vector3(35, 7, -35), Quaternion.identity);
                }
            }
        }  
    }
}
